<?php include 'includes/header.php'; ?>

  <h2>Oldalkategóriák</h2>

  <div class="card">
    <h3>Frontend oldalak</h3>
    <p>Reszponzív, modern kinézetű weboldalak HTML, CSS és JavaScript segítségével. Egyedi design, "telefonbarát" megjelenés.</p>
    <ul>
      <li>Landing page-ek</li>
      <li>Portfólió oldalak</li>
      <li>Üzleti weboldalak</li>
    </ul>
  </div>

  <div class="card">
    <h3>Backend megoldások</h3>
    <p>Egyszerű adatfeldolgozások, űrlapkezelés, emailküldés, PHP+SQL</p>
  </div>

  <div class="card">
    <h3>Fullstack oldalak</h3>
    <p>Fullstack oldalak vue.js,laravel használatával.</p>
  </div>

<?php include 'includes/footer.php'; ?>

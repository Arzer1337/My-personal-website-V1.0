<?php include 'includes/header.php'; ?>

  <h2>Árlista</h2>

  <div class="arlista">
  <div class="ar-tetel">
    <span class="szolgaltatas">Frontend oldalak</span>
    <span class="ar">30 000 Ft</span>
  </div>
  <div class="ar-tetel">
    <span class="szolgaltatas">Backend oldalak</span>
    <span class="ar">50 000 Ft</span>
  </div>
  <div class="ar-tetel">
    <span class="szolgaltatas">Fullstack</span>
    <span class="ar">100 000Ft</span>
</div>
</div>



<?php include 'includes/footer.php'; ?>


<?php
include 'includes/header.php';

if (isset($_GET['status'])) {
  switch ($_GET['status']) {
    case 'siker':
      echo '<p style="color: #00ffcc;">Köszönjük, az üzeneted elküldtük!</p>';
      break;
    case 'hiba':
      echo '<p style="color: #ff3366;">Hiba történt az üzenet küldésekor.</p>';
      break;
    case 'ervenytelen':
      echo '<p style="color: #ffff00;">Kérjük, tölts ki minden mezőt helyesen!</p>';
      break;
  }
}
?>
<?php
include 'send.php';
?>
  <h2>Küdlj felkérést:</h2>

  <form action="send.php" method="POST">
    <label for="name">Név:</label>
    <input type="text" name="name" required>

    <label for="email">Email:</label>
    <input type="email" name="email" required>

    <label for="message">Üzenet:</label>
    <textarea name="message" rows="5" required></textarea>

    <button type="submit">Küldés</button>
  </form>

<?php include 'includes/footer.php'; ?>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $name = strip_tags(trim($_POST["name"]));
  $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
  $message = htmlspecialchars(trim($_POST["message"]));

  if (!empty($name) && !empty($message) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $to = "fejesdani122@gmail.com";
    $subject = "Üzenet az oldalról: $name";
    $headers = "From: $email";

    $body = "Név: $name\nEmail: $email\n\nÜzenet:\n$message";

    if (mail($to, $subject, $body, $headers)) {
      header("Location: elerhetoseg.php?status=siker");
      exit;
    } else {
      header("Location: elerhetoseg.php?status=hiba");
      exit;
    }
  } else {
    header("Location: elerhetoseg.php?status=ervenytelen");
    exit;
  }
}
?>

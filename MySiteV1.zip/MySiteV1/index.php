<?php include 'includes/header.php'; ?>

  <h2>Üdvözöllek!</h2>
  <p>Fejes Dániel vagyok, az Eszterházy Károly Katolikus Egyetem programtervező informatikus hallgatója.<br>
  <br>
    Jelenleg másodéves vagyok, 6 éve foglalkozom informatikával, és a webprogramozásban találtam meg a helyem. Folyamatosan fejlesztem magam, hogy lépést tudjak tartani a mai világ elvárásaival.
    Képzettségeim: CISCO NETWORK ACADEMY CCNA1 Routing and switching
                  Műszaki informatikus OKJ
                  Irodai informatikus OKJ
      Felsőfokú tanulmányok:EKKE Programtervező informatikus Bsc / Szoftvertervező spec.
    <br>
    <br>
    Ha szeretnél maximum 2 hét alatt kézhezkapni egy stabilan működő, korszerű akár vállalati, akár csak egy "maszekolós" oldalt, kérlek írj egy üzenetet az elérhetőség oldalon. 

  </p>

<?php include 'includes/footer.php'; ?>

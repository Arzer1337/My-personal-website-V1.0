<?php
$current = basename($_SERVER['PHP_SELF']);
?>

<!DOCTYPE html>
<html lang="hu">
<head>
  <meta charset="UTF-8">
  <title>Fejes Dániel Webprogramozás</title>
  <link rel="stylesheet" href="css/style.css">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500&display=swap" rel="stylesheet">
</head>
<body>
  <header>
    <h1>Fejes Dániel Webprogramozás</h1>
    <nav>
      <a href="index.php" class="<?= $current == 'index.php' ? 'active' : '' ?>">Főoldal</a>
      <a href="kategoriak.php" class="<?= $current == 'kategoriak.php' ? 'active' : '' ?>">Oldalkategóriák</a>
      <a href="arlista.php" class="<?= $current == 'arlista.php' ? 'active' : '' ?>">Árlista</a>
      <a href="elerhetoseg.php" class="<?= $current == 'elerhetoseg.php' ? 'active' : '' ?>">Elérhetőség</a>
    </nav>
  </header>
  <main>

